package com.igorcordeiroszeremeta.coronavirusapp3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Resultado extends AppCompatActivity {

    private TextView textoDoResultadoFinal;
    private Button tratamento ,prevencao;
    private View v;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.resultado);

    tratamento = findViewById(R.id.tratamento);

    prevencao = findViewById(R.id.prevencao);

    textoDoResultadoFinal = findViewById(R.id.textoDoResultadoFinal);

    Teste1 teste1 = new Teste1();
    int resultadoDoTeste1 = teste1.getResultadoDaPrimeiraPagina();

    Teste2 teste2 = new Teste2();
    int resultadoDoTeste2 = teste2.getResultadoDaSegundaPagina();

    Teste3 teste3 = new Teste3();
    int resultadoDoTeste3 = teste3.getResultadoDaTerceiraPagina();

    Teste4 teste4 = new Teste4();
    int resultadoDoTeste4 = teste4.getResultadoDaQuartaPagina();

    int resultadoDoTeste = resultadoDoTeste1 + resultadoDoTeste2 + resultadoDoTeste3 + resultadoDoTeste4;
}

    public void conferirResultado(View v, int resultadoDoTeste) {

        if (resultadoDoTeste > 0 && resultadoDoTeste <= 3) {
            textoDoResultadoFinal.setText("Você apresenta os sintomas leves. \nPor favor, se cuide.");

        } else if (resultadoDoTeste >= 4 && resultadoDoTeste < 12) {
            textoDoResultadoFinal.setText("Você apresenta os sintomas medianos. Por favor, tome cuidado. Em caso de piora, por favor, procure urgentemente uma unidade de saúde.");

        } else if (resultadoDoTeste >= 12 && resultadoDoTeste <= 35) {
            textoDoResultadoFinal.setText("Você apresenta os sintomas graves. \nPor favor, vá para uma unidade de \nsaúde.");

        } else if (resultadoDoTeste > 35) {
            textoDoResultadoFinal.setText("Você apresenta sintomas gravíssimos. Por favor, procure o mais rápido \npossível uma unidade de saúde.");
        }

    }

    public void tratamentos(View v){
        Intent it = new Intent(getApplicationContext(),Tratamentos1.class);
        startActivity(it);

    }
    public void prevencao(View v){
        Intent it = new Intent(getApplicationContext(),Prevencao1.class);
        startActivity(it);
    }
/*
    public void resetar(View v) {

        recreate();

        if (febre.isChecked()) {
            febre.setChecked(false);
        }

        if (tosseSeca.isChecked()) {
            tosseSeca.setChecked(false);
        }

        if (cansaco.isChecked()) {
            cansaco.setChecked(false);
        }

        if (doresEDesconfortos.isChecked()) {
            doresEDesconfortos.setChecked(false);
        }

        if (dorDeGarganta.isChecked()) {
            dorDeGarganta.setChecked(false);
        }


        if (diarreia.isChecked()) {
            diarreia.setChecked(false);
        }

        if (conjuntivite.isChecked()) {
            conjuntivite.setChecked(false);
        }

        if (dorDeCabeca.isChecked()) {
            dorDeCabeca.setChecked(false);
        }

        if (perdaDePaladarOuOlfato.isChecked()) {
            perdaDePaladarOuOlfato.setChecked(false);
        }

        if (erupcaoCutanea.isChecked()) {
            erupcaoCutanea.setChecked(false);
        }

        if (dificuldadesParaRespirar.isChecked()) {
            dificuldadesParaRespirar.setChecked(false);
        }

        if (dorOuPressaoNoPeito.isChecked()) {
            dorOuPressaoNoPeito.setChecked(false);
        }

        if (perdaDeFalaOuPerdaDeMovimento.isChecked()) {
            perdaDeFalaOuPerdaDeMovimento.setChecked(false);
        }

            textoDoResultadoFinal.setText("");
    }
    */
}