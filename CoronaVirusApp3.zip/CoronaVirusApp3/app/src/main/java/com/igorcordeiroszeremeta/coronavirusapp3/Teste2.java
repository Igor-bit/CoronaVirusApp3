package com.igorcordeiroszeremeta.coronavirusapp3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

import androidx.appcompat.app.AppCompatActivity;

public class Teste2 extends AppCompatActivity {

    private Button botaoTeste2;
    private CheckBox doresEDesconfortos;
    private CheckBox dorDeGarganta;
    private CheckBox diarreia;
    int resultadoDaSegundaPagina = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.teste2);

        doresEDesconfortos = findViewById(R.id.doresEDesconfortos);

        dorDeGarganta = findViewById(R.id.dorDeGarganta);

        diarreia = findViewById(R.id.diarreia);

        botaoTeste2 = findViewById(R.id.botaoTeste2);
        botaoTeste2.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Teste3.class);
                startActivity(intent);
            }
        });
    }
        public int getResultadoDaSegundaPagina(View v) {
            if (doresEDesconfortos.isChecked()) {
                resultadoDaSegundaPagina += 5;
            }

            if (dorDeGarganta.isChecked()) {
                resultadoDaSegundaPagina += 5;
            }

            if (diarreia.isChecked()) {
                resultadoDaSegundaPagina += 5;
            }

            return resultadoDaSegundaPagina;
        }
    }