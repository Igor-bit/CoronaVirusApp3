package com.igorcordeiroszeremeta.coronavirusapp3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

import androidx.appcompat.app.AppCompatActivity;

public class Teste1 extends AppCompatActivity {

    private Button botaoTeste1;
    int resultadoDaPrimeiraPagina = 0;
    private CheckBox febre;
    private CheckBox tosseSeca;
    private CheckBox cansaco;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.teste);

        febre = findViewById(R.id.febre);

        tosseSeca = findViewById(R.id.tosseSeca);

        cansaco = findViewById(R.id.cansaco);

        botaoTeste1 = findViewById(R.id.botaoTeste1);
        botaoTeste1.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Teste2.class);
                startActivity(intent);
            }
        });
    }

    public int getResultadoDaPrimeiraPagina() {
        if (febre.isChecked()) {
            resultadoDaPrimeiraPagina += 1;
        }

        if (tosseSeca.isChecked()) {
            resultadoDaPrimeiraPagina += 1;
        }

        if (cansaco.isChecked()) {
            resultadoDaPrimeiraPagina += 1;
        }

        return resultadoDaPrimeiraPagina;
    }
}