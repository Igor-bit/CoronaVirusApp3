package com.igorcordeiroszeremeta.coronavirusapp3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

import androidx.appcompat.app.AppCompatActivity;

import com.igorcordeiroszeremeta.coronavirusapp3.R;

public class Teste4 extends AppCompatActivity {

    private Button botaoTeste4;
    private CheckBox dificuldadesParaRespirar;
    private CheckBox dorOuPressaoNoPeito;
    private CheckBox perdaDeFalaOuPerdaDeMovimento;
    int resultadoDaQuartaPagina = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.teste4);

        dificuldadesParaRespirar = findViewById(R.id.dificuldadesParaRespirar);

        dorOuPressaoNoPeito = findViewById(R.id.dorOuPressaoNoPeito);

        perdaDeFalaOuPerdaDeMovimento = findViewById(R.id.perdaDeFalaOuMovimento);

        botaoTeste4 = findViewById(R.id.botaoTeste4);
        botaoTeste4.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Resultado.class);
                startActivity(intent);
            }
        });
    }

    public int getResultadoDaQuartaPagina(View v) {
        if (dificuldadesParaRespirar.isChecked()) {
            resultadoDaQuartaPagina += 12;
        }

        if (dorOuPressaoNoPeito.isChecked()) {
            resultadoDaQuartaPagina += 12;
        }

        if (perdaDeFalaOuPerdaDeMovimento.isChecked()) {
            resultadoDaQuartaPagina += 12;
        }
            return resultadoDaQuartaPagina;
    }
}
